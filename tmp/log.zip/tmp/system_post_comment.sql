INSERT INTO system_post_comment (id,comment,system_user_id,system_post_id,created_at) VALUES (1,'My first comment',1,2,'2022-11-03 15:22:11');
INSERT INTO system_post_comment (id,comment,system_user_id,system_post_id,created_at) VALUES (2,'Another comment',1,2,'2022-11-03 15:22:17');
INSERT INTO system_post_comment (id,comment,system_user_id,system_post_id,created_at) VALUES (3,'The best comment',2,2,'2022-11-03 15:23:11');
INSERT INTO system_post_comment (id,comment,system_user_id,system_post_id,created_at) VALUES (4,'Gostei demais',1,2,'2023-03-18 00:26:17');
