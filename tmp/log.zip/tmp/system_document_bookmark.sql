INSERT INTO system_document_bookmark (id,system_user_id,system_document_id) VALUES (1,1,1);
