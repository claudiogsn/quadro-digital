INSERT INTO system_user_unit (id,system_user_id,system_unit_id) VALUES (5,3,4);
INSERT INTO system_user_unit (id,system_user_id,system_unit_id) VALUES (6,1,1);
INSERT INTO system_user_unit (id,system_user_id,system_unit_id) VALUES (7,1,2);
INSERT INTO system_user_unit (id,system_user_id,system_unit_id) VALUES (8,2,1);
INSERT INTO system_user_unit (id,system_user_id,system_unit_id) VALUES (9,2,2);
INSERT INTO system_user_unit (id,system_user_id,system_unit_id) VALUES (10,2,6);
