INSERT INTO system_document_user (id,document_id,system_user_id) VALUES (1,1,3);
