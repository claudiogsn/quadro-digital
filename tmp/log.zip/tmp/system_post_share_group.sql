INSERT INTO system_post_share_group (id,system_group_id,system_post_id) VALUES (1,1,1);
INSERT INTO system_post_share_group (id,system_group_id,system_post_id) VALUES (2,2,1);
INSERT INTO system_post_share_group (id,system_group_id,system_post_id) VALUES (3,1,2);
INSERT INTO system_post_share_group (id,system_group_id,system_post_id) VALUES (4,2,2);
