INSERT INTO system_wiki_tag (id,system_wiki_page_id,tag) VALUES (3,1,'manual');
INSERT INTO system_wiki_tag (id,system_wiki_page_id,tag) VALUES (5,4,'manual');
INSERT INTO system_wiki_tag (id,system_wiki_page_id,tag) VALUES (6,3,'manual');
INSERT INTO system_wiki_tag (id,system_wiki_page_id,tag) VALUES (7,2,'manual');
