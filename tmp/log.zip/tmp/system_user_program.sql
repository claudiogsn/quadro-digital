INSERT INTO system_user_program (id,system_user_id,system_program_id) VALUES (1,2,7);
