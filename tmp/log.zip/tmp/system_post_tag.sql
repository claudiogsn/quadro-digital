INSERT INTO system_post_tag (id,system_post_id,tag) VALUES (1,1,'novidades');
INSERT INTO system_post_tag (id,system_post_id,tag) VALUES (2,2,'novidades');
