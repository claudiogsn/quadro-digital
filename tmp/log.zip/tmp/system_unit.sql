INSERT INTO system_unit (id,name,connection_name) VALUES (1,'José Américo','unit_a');
INSERT INTO system_unit (id,name,connection_name) VALUES (2,'Manaira','unit_b');
INSERT INTO system_unit (id,name,connection_name) VALUES (3,'Expedicionarios','');
INSERT INTO system_unit (id,name,connection_name) VALUES (4,'Mangabeira','');
INSERT INTO system_unit (id,name,connection_name) VALUES (5,'Geisel','');
INSERT INTO system_unit (id,name,connection_name) VALUES (6,'Bessa','');
INSERT INTO system_unit (id,name,connection_name) VALUES (7,'Intermares','');
INSERT INTO system_unit (id,name,connection_name) VALUES (8,'Tambau','');
INSERT INTO system_unit (id,name,connection_name) VALUES (9,'Cabo Branco','');
