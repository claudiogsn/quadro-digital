INSERT INTO system_post_like (id,system_user_id,system_post_id,created_at) VALUES (1,1,2,'2023-03-18 00:25:53');
