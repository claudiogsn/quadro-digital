INSERT INTO system_document_category (id,name) VALUES (1,'Documentação');
