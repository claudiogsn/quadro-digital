INSERT INTO system_folder (id,system_user_id,created_at,name,in_trash,system_folder_parent_id) VALUES (1,1,'2023-03-18','Teste','','');
