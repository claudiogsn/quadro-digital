INSERT INTO system_group (id,name) VALUES (1,'Admin');
INSERT INTO system_group (id,name) VALUES (2,'Standard');
