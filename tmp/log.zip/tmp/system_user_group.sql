INSERT INTO system_user_group (id,system_user_id,system_group_id) VALUES (4,3,1);
INSERT INTO system_user_group (id,system_user_id,system_group_id) VALUES (5,1,1);
INSERT INTO system_user_group (id,system_user_id,system_group_id) VALUES (6,1,2);
INSERT INTO system_user_group (id,system_user_id,system_group_id) VALUES (7,2,2);
