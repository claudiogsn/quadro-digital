INSERT INTO system_wiki_share_group (id,system_group_id,system_wiki_page_id) VALUES (1,1,1);
INSERT INTO system_wiki_share_group (id,system_group_id,system_wiki_page_id) VALUES (2,2,1);
INSERT INTO system_wiki_share_group (id,system_group_id,system_wiki_page_id) VALUES (3,1,2);
INSERT INTO system_wiki_share_group (id,system_group_id,system_wiki_page_id) VALUES (4,2,2);
INSERT INTO system_wiki_share_group (id,system_group_id,system_wiki_page_id) VALUES (5,1,3);
INSERT INTO system_wiki_share_group (id,system_group_id,system_wiki_page_id) VALUES (6,2,3);
INSERT INTO system_wiki_share_group (id,system_group_id,system_wiki_page_id) VALUES (7,1,4);
INSERT INTO system_wiki_share_group (id,system_group_id,system_wiki_page_id) VALUES (8,2,4);
