INSERT INTO system_message (id,system_user_id,system_user_to_id,subject,message,dt_message,checked) VALUES (1,1,1,'Oi','Oi','2023-03-18 01:05:17','N');
INSERT INTO system_message (id,system_user_id,system_user_to_id,subject,message,dt_message,checked) VALUES (2,1,2,'Teste ','Teste envio','2023-03-18 01:05:39','N');
